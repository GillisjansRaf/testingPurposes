<?php
/**
 * Created by PhpStorm.
 * User: thibeau
 * Date: 17/04/2018
 * Time: 10:44
 */

function getAllCategories()
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM categorie");
        $stmt->execute();
        $categories = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return ($categories);
}

function getCategorie($id)
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM categorie WHERE idCategorie = $id");
        $stmt->execute();
        $categories = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return ($categories);
}

function getCategorieCount()
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM categorie");
        $stmt->execute();
        $categories = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return (count($categories));
}

function getAllChapters()
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM chapter");
        $stmt->execute();
        $chapters = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return ($chapters);
}

function getChapter($id)
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM chapter WHERE idChapter = $id");
        $stmt->execute();
        $chapters = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return ($chapters);
}

function getChapterCount()
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM chapter");
        $stmt->execute();
        $chapters = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return (count($chapters));
}

function getAllQuestions()
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT *,chapter.nameChapter,categorie.nameCategorie FROM question LEFT JOIN chapter ON question.idChapter = chapter.idChapter LEFT JOIN categorie ON chapter.idCategorie = categorie.idCategorie");
        $stmt->execute();
        $questions = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return ($questions);
}

function addQuestion($question, $chapter, $nameAnswerRight, $nameAnswerWrong1, $nameAnswerWrong2, $nameAnswerWrong3)
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("INSERT INTO question(nameQuestion, idChapter) VALUES(:question,:chapter)");
        $conn->bindParam(':question', $question);
        $conn->bindParam(':chapter', $chapter);
        $stmt->execute();
        addAnswer($nameAnswerRight, $nameAnswerWrong1, $nameAnswerWrong2, $nameAnswerWrong3);
    } catch (PDOException $e) {
        die($e->getMessage());
    }
}

function getLastQuestionId()
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT idQuestion FROM question ORDER BY idQuestion DESC LIMIT 1");
        $stmt->execute();
        $lastQuestionId = $stmt->fetchAll();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    return ($lastQuestionId);
}

function addAnswer($nameAnswerRight, $nameAnswerWrong1, $nameAnswerWrong2, $nameAnswerWrong3)
{
    try {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "cage";

        $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("INSERT INTO answer(idQuestion, nameAnswer, IsCorrect) VALUES(:idQuestion, :nameAnswerRight, 1),(:idQuestion, :nameAnswerWrong1, 0),(:idQuestion, :nameAnswerWrong2, 0),(:idQuestion, :nameAnswerWrong3, 0)");
        $conn->bindParam(':idQuestion', getLastQuestionId());
        $conn->bindParam(':nameAnswerRight', $nameAnswerRight);
        $conn->bindParam(':nameAnswerWrong1', $nameAnswerWrong1);
        $conn->bindParam(':nameAnswerWrong2', $nameAnswerWrong2);
        $conn->bindParam(':nameAnswerWrong3', $nameAnswerWrong3);
        $stmt->execute();
    } catch (PDOException $e) {
        die($e->getMessage());
    }
}

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8"/>
    <meta name="author" content="Thibeau Cardon"/>
    <title>View Question</title>

    <link rel="stylesheet" type="text/css" href="assets/css/CAGe-style.css"/>
</head>
<body>
<?php
include_once("functions.php");
?>
<div id="wrapper">
    <table>
        <th>
        <td id="Question"></td>
        <td id="chapter"></td>
        <td id="Categorie"></td>
        <td id="Actions"></td>
        </th>
        <?php
        $questions = getAllQuestions();
        foreach($questions as $question)
        {
            echo('<tr>');

            echo('<td>');
            echo($question['nameQuestion']);
            echo('</td>');

            echo('<td>');
            echo($question['nameChapter']);
            echo('</td>');

            echo('<td>');
            echo($question['nameCategorie']);
            echo('</td>');

            echo('</tr>');
        }
        ?>
        <tr></tr>
    </table>
</div>
</body>
</html>